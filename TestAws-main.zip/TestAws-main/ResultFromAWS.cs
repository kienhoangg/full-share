
using System.Collections.Generic;

namespace TestConsole123
{
    public class ResultFromAWS
    {
        public string NextToken { get; set; }
        public List<TemplateMetaData> TemplatesMetadata { get; set; }
    }
}
