namespace TestConsole123
{
    public class TemplateMetaData
    {
        public double CreatedTimestamp { get; set; }
        public string TemplateName { get; set; }
    }
}
